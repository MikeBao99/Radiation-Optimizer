# Harvard APMTH 121 
### Extreme Optimization Project 1: Optimizing Radiation Cancer Therapy <br/>
Team Name: Marshmallow Mateys <br/>
Team Members: Mike Bao, Jonathan Huang, Luis Viceira <br/>


Please see the following folders for the files corresponding to each task: <br/>
Task 1.1 and 2.1: "tsk1" <br/>
Task 1.2 and 2.2: "tsk2" <br/>
Task 1.3 and 2.3: "tsk3" and "tsk3_sm" <br/>
Task 1.4, and 2.4: "tsk41" and "tsk41_sm" for the 1st modification; "tsk42" and "tsk42_sm" for the 2nd modification <br/>

###### Implemented using AMPL, CPLEX, and MATLAB

